// script.js

document.addEventListener('DOMContentLoaded', () => {
    const productCards = document.querySelectorAll('.product-card');
    const cart = [];
    const cartCountElement = document.getElementById('cartCount');
    const cartItemsElement = document.getElementById('cartItems');
    const checkoutBtn = document.getElementById('checkoutBtn');
    const cookieDialog = document.getElementById('cookieDialog');
    const acceptBtn = document.getElementById('acceptBtn');
    const rejectBtn = document.getElementById('rejectBtn');

    productCards.forEach(card => {
        const addToCartBtn = card.querySelector('.add-to-cart');
        const removeFromCartBtn = card.querySelector('.remove-from-cart');

        addToCartBtn.addEventListener('click', () => {
            addToCart(card);
        });

        removeFromCartBtn.addEventListener('click', () => {
            removeFromCart(card);
        });
    });

    checkoutBtn.addEventListener('click', () => {
        if (cart.length > 0) {
            alert('Pedido realizado correctamente');
            cart.length = 0; // Vaciar carrito después de realizar la compra
            updateCartView();
        } else {
            alert('Tu carrito está vacío');
        }
    });

    function addToCart(card) {
        const productId = card.id;
        const title = card.querySelector('h2').textContent;
        if (!cart.some(item => item.id === productId)) {
            cart.push({ id: productId, title });
            updateCartCount();
            updateCartView();
        }
    }

    function removeFromCart(card) {
        const productId = card.id;
        const index = cart.findIndex(item => item.id === productId);
        if (index > -1) {
            cart.splice(index, 1);
            updateCartCount();
            updateCartView();
        }
    }

    function updateCartCount() {
        cartCountElement.textContent = cart.length;
    }

    function updateCartView() {
        cartItemsElement.innerHTML = '';
        cart.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item.title;
            cartItemsElement.appendChild(li);
        });
    }

    // Dialog de cookies
    if (!document.cookie.includes('cookieAccepted=true')) {
        cookieDialog.showModal();
    }

    acceptBtn.addEventListener('click', () => {
        document.cookie = 'cookieAccepted=true; max-age=31536000'; // Cookie de aceptación válida por un año
        cookieDialog.close();
    });

    rejectBtn.addEventListener('click', () => {
        cookieDialog.close();
    });
});
