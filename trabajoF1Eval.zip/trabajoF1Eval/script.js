// Lista de usuarios registrados (simulado)
let users = [];

// Mostrar formulario de registro
function showRegisterForm() {
    document.getElementById('login-section').style.display = 'none';
    document.getElementById('register-section').style.display = 'block';
}

// Mostrar formulario de inicio de sesión
function showLoginForm() {
    document.getElementById('register-section').style.display = 'none';
    document.getElementById('login-section').style.display = 'block';
}

// Manejar registro
function handleRegister() {
    const name = document.getElementById('register-name').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value.trim();

    if (users.some(user => user.email === email)) {
        alert('Este correo ya está registrado.');
    } else {
        users.push({ name, email, password });
        alert('Registro exitoso. Ahora puedes iniciar sesión.');
        showLoginForm();
    }
}

function handleLogin() {
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value.trim();

    // Buscar usuario en la lista de registrados
    const user = users.find(user => user.email === email && user.password === password);

    if (user) {
        // Redirigir a index.html tras iniciar sesión
        window.location.href = 'index.html';
    } else {
        alert('Correo o contraseña incorrectos.');
    }
}

const btnCookie = document.getElementById("btnCookie");
btnCookie.addEventListener("click", (e) => {
    btnCookie.parentElement.remove();
});