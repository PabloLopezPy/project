function getWeather() {
    var ciudad = document.getElementById('ciudad').value.trim();
    if (ciudad === '') {
        alert('Por favor, ingresa el nombre de una ciudad.');
        return;
    }

    var apiKey = '6bca215856811583645de9a10dba84f1'; // Reemplaza con tu clave API
    var url = `https://api.openweathermap.org/data/2.5/weather?q=${ciudad}&appid=${apiKey}&units=metric&lang=es`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error ${response.status}: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.cod === 200) {
                document.getElementById('resultado').innerHTML = `
                    <h2>${data.name}, ${data.sys.country}</h2>
                    <p>Temperatura: ${data.main.temp}°C</p>
                    <p>Descripción: ${data.weather[0].description}</p>
                `;
            } else {
                document.getElementById('resultado').innerHTML = `<p>${data.message}</p>`;
            }
        })
        .catch(error => {
            console.error('Error al obtener datos:', error);
            document.getElementById('resultado').innerHTML = `<p>Hubo un error al obtener los datos. Por favor, inténtelo de nuevo más tarde.</p>`;
        });
}
