document.addEventListener('DOMContentLoaded', () => {
    const cookieDialog = document.getElementById("cookie-dialog");
    const acceptCookiesButton = document.getElementById("accept-cookies");

    if (!localStorage.getItem("cookiesAccepted")) {
        cookieDialog.showModal();
    }

    acceptCookiesButton.addEventListener("click", () => {
        localStorage.setItem("cookiesAccepted", "true");
        cookieDialog.close();
    });

    const cart = [];

    const productos = [
        { id: 1, imagen: "images/monsterBlanco.jpg", titulo: "Monster Blanco", precio: "2.50€" },
        { id: 2, imagen: "images/monsterVerde.png", titulo: "Monster Energy", precio: "3.00€" },
        { id: 3, imagen: "images/monster-mangoLoco.jpg", titulo: "Monster Mango Loco", precio: "2.80€" }
    ];

    const productTemplate = document.getElementById("product-template");
    const container = document.querySelector(".container");

    productos.forEach(producto => {
        const productCard = productTemplate.content.cloneNode(true);

        productCard.querySelector(".product-image").src = producto.imagen;
        productCard.querySelector(".product-image").alt = producto.titulo;
        productCard.querySelector(".product-title").textContent = producto.titulo;
        productCard.querySelector(".product-price").textContent = producto.precio;

        const cartButton = productCard.querySelector(".cart-button");

        cartButton.addEventListener("click", () => {
            if (!cart.find(item => item.id === producto.id)) {
                cart.push({ ...producto, cantidad: 1 });
                alert(`${producto.titulo} añadido al carrito.`);
            } else {
                alert(`${producto.titulo} ya está en el carrito.`);
            }
            console.log("Carrito:", cart);
        });

        container.appendChild(productCard);
    });

    const checkoutButton = document.getElementById("proceedCheckoutButton");
    checkoutButton.addEventListener("click", () => {
        if (cart.length === 0) {
            alert("El carrito está vacío. Añade productos para continuar.");
            return;
        }

        const resumen = cart.map(item => {
            return `- ${item.titulo} x${item.cantidad} - ${item.precio}`;
        }).join("\n");

        const total = cart.reduce((acc, item) => {
            const price = parseFloat(item.precio.replace("€", ""));
            return acc + price * item.cantidad;
        }, 0);

        const confirmacion = confirm(
            `Resumen de tu compra:\n\n${resumen}\n\nTotal: $${total.toFixed(2)}\n\n¿Deseas confirmar tu compra?`
        );

        if (confirmacion) {
            alert("¡Gracias por tu compra! Tu pedido ha sido procesado.");
            cart.length = 0; 
            console.log("Carrito vacío:", cart);
            cartContainer.style.display = "none"; 
        }
    });

    const viewCartButton = document.getElementById("viewCartButton");
    const cartContainer = document.getElementById("cart-container");
    const closeCartButton = document.getElementById("closeCart");

    viewCartButton.addEventListener("click", () => {
        displayCart();
    });

    closeCartButton.addEventListener("click", () => {
        cartContainer.style.display = "none";
    });

    function displayCart() {
        cartContainer.style.display = "block";
        const cartList = cartContainer.querySelector(".cart-list");
        cartList.innerHTML = "";

        if (cart.length === 0) {
            cartList.innerHTML = "<p>No hay productos en el carrito.</p>";
        } else {
            cart.forEach(item => {
                const productElement = document.createElement("div");
                productElement.innerHTML = `<p>${item.titulo} - ${item.precio} x${item.cantidad}</p>`;
                cartList.appendChild(productElement);
            });
        }
    }
});
